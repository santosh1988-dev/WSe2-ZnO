# WSe2/ZnO interface model – data and code

**Paper:** "Interfacial Exciton Dynamics and Charge Transfer Coupling in WSe2/ZnO Hybrid Systems"
**Journal / submission:** Computational Materials Science, COMMAT-D-26-03981
**Corresponding author:** R. A. Zargar (rayeesphy.13@gmail.com)

No experimental data were generated. `WSe2_ZnO_model.py` implements the equations of the revised manuscript in SI units and regenerates Figures 2-6 (PNG 300 dpi + vector PDF) and the CSV files; `run_output.txt` is the console output (Table 2 values, fit exponent, sensitivities).

| File | Content |
|---|---|
| `WSe2_ZnO_model.py` | model script (prints Table 2 values, fit exponent, sensitivities) |
| `Figure2_interfacial_electrostatics.png`, `data_Figure2.csv` | V_gap(d), sigma(d) (Eq. 2) |
| `Figure3_potential_profile.png`, `data_Figure3.csv` | V(z), eps(z) at d = 0.30 nm |
| `Figure4_thomas_fermi.png`, `data_Figure4.csv` | 2D Thomas-Fermi length (Eq. 6) |
| `Figure5_optical_modulation.png`, `data_Figure5a.csv`, `data_Figure5b.csv` | QCSE shift (Eq. 8), log-log fit exponent, upper bound |
| `Figure6_generalisation.png`, `data_Figure6.csv` | upper-bound shifts for other TMD/oxide pairs |
| `data_sensitivity.csv` | Table 3: shift vs eps_gap, N_D, DeltaE_C at d = 0.29 nm |

## Equations implemented (numbering as in the revised manuscript)
- (2) charge balance: DeltaE_C/e = sigma^2/(2 eps0 eps_ZnO e N_D) + sigma d/(eps0 eps_gap), solved for sigma(d); eta = V_gap/V_bi
- (3) sigma_dep = sqrt(2 eps0 eps_ZnO e N_D V_bi) (d -> 0 limit)
- (4) sigma = eps0 eps_gap V_bi/d (gap-limited limit, eta = 1)
- (5) E_perp = sigma/(eps0 eps_WSe2)
- (6) lambda_TF = 4 pi eps0 eps hbar^2/(g e^2 m*)
- (8) dE_ex = -(1/2) alpha_ex E_perp^2   (Eq. 7, the exciton Hamiltonian, is not evaluated numerically)

## Parameters (Table 1 of the manuscript)
eps_WSe2 = 7.0, eps_ZnO = 8.5, eps_gap = 1.0, DeltaE_C = 0.30 eV (nominal) / 0.50 eV (upper), N_D = 1e18 cm^-3,
d = 0.29-3.0 nm, m* = 0.45 m0, g = 2, alpha_ex = 5e-38 J/(V/m)^2 (assumed), T = 300 K.

## Run
```
pip install numpy matplotlib
python WSe2_ZnO_model.py
```
## Requirements
Python >= 3.9 with `numpy` and `matplotlib` (see `requirements.txt`). Tested with Python 3.12, numpy 2.4, matplotlib 3.10. Runtime: a few seconds.

## Citation
Please cite the associated article and this archive: Chackrabarti, S., Maini, A., Parrey, I. R., Zargar, R. A., Swain, K. K., Kumar, V., "Interfacial Exciton Dynamics and Charge Transfer Coupling in WSe2/ZnO Hybrid Systems" (under review), and the archive DOI: [to be added after deposit].

License: CC BY 4.0.
