"""
WSe2/ZnO interface model -- corrected, SI-unit script (revised version)
Manuscript: "Interfacial Exciton Dynamics and Charge Transfer Coupling in
WSe2/ZnO Hybrid Systems" (Computational Materials Science, COMMAT-D-26-03981)

Equations implemented (numbering as in the revised manuscript)
  (1)  Poisson equation (abrupt-depletion solution used, see Eq. 2)
  (2)  V_bi = DeltaE_C/e = sigma^2/(2 eps0 eps_ZnO e N_D) + sigma d/(eps0 eps_gap)
       solved for sigma(d) (charge balance: ZnO depletion layer in series with the
       van der Waals gap); eta = V_gap/V_bi
  (3)  sigma_dep = sqrt(2 eps0 eps_ZnO e N_D V_bi)             [d -> 0 limit]
  (4)  sigma = eps0 eps_gap V_bi/d                             [gap-limited limit, eta = 1]
  (5)  E_perp = sigma/(eps0 eps_WSe2)   (field acting on the WSe2 exciton)
  (6)  lambda_TF = 4 pi eps0 eps hbar^2 /(g e^2 m*)            [2D Thomas-Fermi]
  (8)  dE_ex = -(1/2) alpha_ex E_perp^2                        [QCSE, 2nd order]
       (Eq. 7, the exciton Hamiltonian, is not evaluated numerically)
Run:  python WSe2_ZnO_model.py     (writes PNG + CSV files, prints Table 2)
"""
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- constants (SI) --------------------------------------------------------
e, eps0, hbar, m0, kB = 1.602176634e-19, 8.8541878128e-12, 1.054571817e-34, 9.1093837e-31, 1.380649e-23
T = 300.0

# ---- parameters (Table 1 of the manuscript) --------------------------------
eps_WSe2, eps_ZnO, eps_gap = 7.0, 8.5, 1.0
eps_eff = 2*eps_WSe2*eps_ZnO/(eps_WSe2+eps_ZnO)          # harmonic mean = 7.68
dEC_nom, dEC_hi = 0.30, 0.50                            # eV (nominal / upper)
N_D = 1e18*1e6                                          # m^-3 (1e18 cm^-3)
d_nm = np.linspace(0.29, 3.0, 400)
m_star, g_deg = 0.45*m0, 2
# alpha_ex: dE = -(1/2) alpha F^2 ; 5e-38 J/(V/m)^2  == 0.312 eV nm^2/V^2 (x1/2 -> 0.156)
alpha_ex = 5e-38                                        # J / (V/m)^2

def sigma_of_d(d_nm, dEC, ND=N_D, eg=eps_gap):
    """Solve a*s^2 + b*s - V = 0 for the interface charge (C/m^2)."""
    d = np.asarray(d_nm)*1e-9
    a = 1.0/(2*eps0*eps_ZnO*e*ND)
    b = d/(eps0*eg)
    return (-b + np.sqrt(b**2 + 4*a*dEC))/(2*a)

def eta_of_d(d_nm, dEC, ND=N_D, eg=eps_gap):
    s = sigma_of_d(d_nm, dEC, ND, eg)
    return s*np.asarray(d_nm)*1e-9/(eps0*eg)/dEC

def E_perp(sig):                      # V/m, field inside WSe2 (Eq. 5)
    return sig/(eps0*eps_WSe2)

def dE_meV(sig):                      # |dE_ex| in meV (Eq. 8)
    return 0.5*alpha_ex*E_perp(sig)**2/e*1e3

def sigma_gap_limit(d_nm, dEC, eg=eps_gap):   # eta = 1 upper bound
    return eps0*eg*dEC/(np.asarray(d_nm)*1e-9)

def lambda_TF(eps, m, g=g_deg):       # Eq. (6), metres
    return 4*np.pi*eps0*eps*hbar**2/(g*e**2*m)

def debye_ZnO(ND):                    # 3D Debye length, metres
    return np.sqrt(eps0*eps_ZnO*kB*T/(e**2*ND))


# ---- common figure style ----------------------------------------------------
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.labelsize": 10,
    "axes.titlesize": 10, "legend.fontsize": 8, "legend.frameon": False, "axes.linewidth": 0.9,
    "xtick.direction": "in", "ytick.direction": "in", "xtick.top": True, "ytick.right": True,
    "figure.dpi": 100, "savefig.dpi": 300})
C1, C2, C3, C4, C5 = "#1f4e9c", "#c0392b", "#2e8b57", "#e08a00", "#6c3483"
def tag(ax, t): ax.text(-0.02, 1.03, t, transform=ax.transAxes, fontsize=11, fontweight="bold", va="bottom", ha="right")
def save(fig, name):
    fig.tight_layout(); fig.savefig(name + ".png", bbox_inches="tight"); fig.savefig(name + ".pdf", bbox_inches="tight"); plt.close(fig)

# ---- Fig 2: electrostatics --------------------------------------------------
sig = sigma_of_d(d_nm, dEC_nom); eta = eta_of_d(d_nm, dEC_nom)
Vgap = eta*dEC_nom; Vdep = dEC_nom - Vgap
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.3))
a0 = ax[0]
a0.axvspan(0.29, 1.0, color="orange", alpha=.13, lw=0)
a0.axhline(dEC_nom, ls="--", c="gray", lw=1.2, label=r"$V_{bi}$ = 0.30 V")
a0.plot(d_nm, Vdep, c=C3, lw=1.8, label=r"$V_{dep}$ (ZnO)")
a0.plot(d_nm, Vgap, c=C1, lw=2, label=r"$V_{gap}(d)$ (gap)")
for dd in (0.30, 1.0):
    k = np.argmin(abs(d_nm-dd)); a0.plot(d_nm[k], Vgap[k], "o", c=C1, ms=4)
    a0.annotate(rf"$\eta$={eta[k]:.2f}", (d_nm[k], Vgap[k]), xytext=(6, -12), textcoords="offset points", fontsize=8, color=C1)
a0.set(xlabel="Interface thickness $d$ (nm)", ylabel="Potential drop (V)", xlim=(0.2, 3.0), ylim=(0, 0.36))
a0.text(0.645, 0.012, "typical vdW\ngap range", fontsize=7, color="#b36b00", ha="center", va="bottom")
a0.legend(loc="lower right", bbox_to_anchor=(1.0, 0.27)); tag(a0, "(a)")
a1 = ax[1]
a1.axvspan(0.29, 1.0, color="orange", alpha=.13, lw=0)
a1.plot(d_nm, sig/sig[0], c=C2, lw=2, label=r"self-consistent, Eq. (2)")
a1.plot(d_nm, 0.29/d_nm, "--", c="gray", lw=1.2, label=r"gap-limited limit, $\sigma\propto 1/d$ (Eq. 4)")
a1.axhline(1, c="k", lw=.4, alpha=.4)
k1 = np.argmin(abs(d_nm-1.0)); a1.annotate(rf"$-${(1-sig[k1]/sig[0])*100:.0f}% at 1 nm", (1.0, sig[k1]/sig[0]),
        xytext=(1.25, 0.84), fontsize=8, color=C2, arrowprops=dict(arrowstyle="-", color=C2, lw=.7))
a1.set(xlabel="Interface thickness $d$ (nm)", ylabel=r"$\sigma(d)\,/\,\sigma(0.29\ \mathrm{nm})$", xlim=(0.2, 3.0), ylim=(0, 1.2))
a1.legend(loc="upper right"); tag(a1, "(b)")
save(fig, "Figure2_interfacial_electrostatics")
with open("data_Figure2.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["d_nm", "V_gap_V", "V_dep_V", "eta", "sigma_C_per_m2", "sigma_norm"])
    for r in zip(d_nm, Vgap, Vdep, eta, sig, sig/sig[0]): w.writerow([f"{x:.6g}" for x in r])

# ---- Fig 3: V(z) and eps(z) at d = 0.3 nm ----------------------------------
d0 = 0.30; s0 = float(sigma_of_d(d0, dEC_nom)); W = s0/(e*N_D); Vg = s0*d0*1e-9/(eps0*eps_gap)
z = np.linspace(-(W*1.25), 3e-9, 6000); dg = d0*1e-9
V = np.where(z < -W, 0.0, np.where(z < 0, e*N_D*(z+W)**2/(2*eps0*eps_ZnO),
     np.where(z < dg, e*N_D*W**2/(2*eps0*eps_ZnO) + s0*z/(eps0*eps_gap), dEC_nom)))
zz = np.linspace(-3e-9, 3e-9, 6000)
eps_z = np.where(zz < 0, eps_ZnO, np.where(zz < dg, eps_gap, eps_WSe2))
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.3))
a0 = ax[0]
a0.axvspan(z[0]*1e9, 0, color=C3, alpha=.08, lw=0); a0.axvspan(0, d0, color="gray", alpha=.35, lw=0)
a0.axvspan(d0, 3.0, color=C1, alpha=.08, lw=0)
a0.plot(z*1e9, V, c=C1, lw=2)
a0.text(-17.5, 0.055, f"ZnO depletion layer\n$W$ = {W*1e9:.0f} nm,  $V_{{dep}}$ = {dEC_nom-Vg:.2f} V", ha="left", va="center", fontsize=8, color=C3)
a0.text(1.6, 0.05, "WSe$_2$", ha="left", fontsize=8, color=C1)
a0.set(xlabel="$z$ (nm)", ylabel="$V(z)$ (V)", xlim=(z[0]*1e9, 3.0), ylim=(-0.01, 0.34)); tag(a0, "(a)")
ins = a0.inset_axes([0.07, 0.40, 0.40, 0.42]); m = (z > -1.5e-9) & (z < 1.5e-9)
ins.plot(z[m]*1e9, V[m], c=C1, lw=1.6); ins.axvspan(0, d0, color="gray", alpha=.35, lw=0)
ins.set_title(f"gap: $V_{{gap}}$ = {Vg:.3f} V", fontsize=7.5, pad=2); ins.tick_params(labelsize=7); ins.set_yticks([0.20, 0.25, 0.30]); ins.set_xlabel("$z$ (nm)", fontsize=7, labelpad=1)
a1 = ax[1]
a1.axvspan(0, d0, color="gray", alpha=.35, lw=0, label="vdW gap")
a1.plot(zz*1e9, eps_z, c=C2, lw=2)
for x, y, t in ((-1.9, 8.9, r"ZnO  $\varepsilon$=8.5"), (0.45, 0.9, r"gap  $\varepsilon$=1"), (0.7, 7.3, r"WSe$_2$  $\varepsilon$=7.0")):
    a1.text(x, y, t, fontsize=8, ha="left")
a1.set(xlabel="$z$ (nm)", ylabel=r"$\varepsilon(z)$", xlim=(-3, 3), ylim=(0, 10.5)); tag(a1, "(b)")
save(fig, "Figure3_potential_profile")
with open("data_Figure3.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["z_nm", "V_V"])
    for r in zip(z*1e9, V): w.writerow([f"{x:.6g}" for x in r])

# ---- Fig 4: 2D Thomas-Fermi length vs eps ; 2D vs 3D density dependence -----
eps_arr = np.linspace(3, 10, 60)
def lam3D(n3, eps, m):
    kF = (3*np.pi**2*n3)**(1/3); EF = hbar**2*kF**2/(2*m)
    return np.sqrt(2*eps0*eps*EF/(3*n3*e**2))
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.3))
a0 = ax[0]
for mm, c in ((0.30, C2), (0.45, C1), (0.60, C3)):
    a0.plot(eps_arr, lambda_TF(eps_arr, mm*m0)*1e9, c=c, lw=2 if mm == 0.45 else 1.4, label=f"$m^*$ = {mm} $m_0$")
a0.plot(7, lambda_TF(7, m_star)*1e9, "o", c=C1, ms=5)
a0.annotate(f"{lambda_TF(7, m_star)*1e9:.2f} nm\n($\\varepsilon$=7, $m^*$=0.45 $m_0$)", (7, lambda_TF(7, m_star)*1e9), xytext=(7.4, 0.17), fontsize=7.5,
            arrowprops=dict(arrowstyle="-", lw=.6))
a0.set(xlabel=r"Relative permittivity $\varepsilon_r$", ylabel=r"$\lambda_{TF}$ (nm)", xlim=(3, 10), ylim=(0, 0.95))
a0.legend(loc="upper left"); tag(a0, "(a)"); a0.text(0.97, 0.05, "2D, $g$ = 2", transform=a0.transAxes, ha="right", fontsize=8)
a1 = ax[1]
n3 = np.logspace(16, 20, 80)*1e6; nc = n3/1e6
a1.loglog(nc, lam3D(n3, 12.9, 0.067*m0)*1e9, c=C2, lw=1.8, label="GaAs (3D)")
a1.loglog(nc, lam3D(n3, 11.7, 0.26*m0)*1e9, c=C3, lw=1.8, label="Si (3D)")
a1.axhline(lambda_TF(7, m_star)*1e9, c=C1, lw=2.2, label=r"WSe$_2$ (2D): independent of $n$")
a1.set(xlabel=r"Carrier density $n$ (cm$^{-3}$ for 3D; any $n$ for 2D)", ylabel=r"$\lambda_{TF}$ (nm)", xlim=(1e16, 1e20), ylim=(0.2, 20))
a1.legend(loc="upper right"); tag(a1, "(b)")
save(fig, "Figure4_thomas_fermi")
with open("data_Figure4.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["eps_r", "lambda_TF_nm_m0.30", "lambda_TF_nm_m0.45", "lambda_TF_nm_m0.60"])
    for a_ in eps_arr: w.writerow([f"{a_:.4g}"] + [f"{lambda_TF(a_, mm*m0)*1e9:.6g}" for mm in (0.30, 0.45, 0.60)])

# ---- Fig 5: QCSE ------------------------------------------------------------
dd5 = np.linspace(0.29, 2.0, 300)
dE_sc = dE_meV(sigma_of_d(dd5, dEC_nom)); dE_ub = dE_meV(sigma_gap_limit(dd5, dEC_hi))
sg = np.logspace(-4, -1.3, 40); dEs = dE_meV(sg)
slope, icpt = np.polyfit(np.log(sg), np.log(dEs), 1)
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.3))
a0 = ax[0]
a0.loglog(sg, dEs, c=C1, lw=2, label=r"Eq. (8), $\alpha_{ex}$ = 5$\times$10$^{-38}$ J (V/m)$^{-2}$")
a0.axvspan(float(sigma_of_d(1.0, dEC_nom)), float(sigma_of_d(0.29, dEC_hi)), color="orange", alpha=.2, lw=0)
a0.text(2.3e-3, 25, "self-consistent\nrange (Table 2)", fontsize=7.5, ha="center", va="center", color="#b36b00")
a0.text(2e-4, 3, f"log-log fit:\nslope = {slope:.2f}", fontsize=9, color=C1)
a0.set(xlabel=r"Interface charge density $\sigma$ (C m$^{-2}$)", ylabel=r"$|\Delta E_{ex}|$ (meV)", xlim=(1e-4, 5e-2)); a0.legend(loc="lower right", fontsize=7); tag(a0, "(a)")
a1 = ax[1]
a1.axhspan(30, 120, color="gray", alpha=.28, lw=0)
a1.text(1.05, 62, "reported PL redshifts\n30-120 meV [13-15]", fontsize=7.5, ha="left", va="center")
a1.semilogy(dd5, dE_ub, "--", c=C2, lw=2, label=r"upper bound ($\eta$=1, $\Delta E_C$=0.50 eV)")
a1.semilogy(dd5, dE_sc, c=C1, lw=2, label=r"self-consistent ($\Delta E_C$=0.30 eV, $N_D$=10$^{18}$ cm$^{-3}$)")
a1.set(xlabel="Interface thickness $d$ (nm)", ylabel=r"$|\Delta E_{ex}|$ (meV)", xlim=(0.29, 2.0), ylim=(1e-2, 300)); a1.legend(loc="lower left", fontsize=7); tag(a1, "(b)")
save(fig, "Figure5_optical_modulation")
with open("data_Figure5a.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["sigma_C_per_m2", "dE_meV"])
    for a_, b_ in zip(sg, dEs): w.writerow([f"{a_:.6g}", f"{b_:.6g}"])
with open("data_Figure5b.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["d_nm", "dE_selfconsistent_dEC0.30_meV", "dE_upperbound_dEC0.50_meV"])
    for r in zip(dd5, dE_sc, dE_ub): w.writerow([f"{x:.6g}" for x in r])

# ---- Fig 6: other pairs (band offsets from the manuscript text) -------------
pairs = {"WSe2/ZnO": 0.30, "MoS2/ZnO": 0.18, "WS2/ZnO": 0.34, "WSe2/TiO2": 0.70, "WS2/TiO2": 0.74}
lab = {"WSe2/ZnO": r"WSe$_2$/ZnO", "MoS2/ZnO": r"MoS$_2$/ZnO", "WS2/ZnO": r"WS$_2$/ZnO", "WSe2/TiO2": r"WSe$_2$/TiO$_2$", "WS2/TiO2": r"WS$_2$/TiO$_2$"}
col = dict(zip(pairs, (C1, C3, C5, C4, C2))); dd6 = np.linspace(0.29, 3.0, 200)
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.3))
with open("data_Figure6.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["pair", "dEC_eV", "d_nm", "dE_upperbound_meV", "ratio_to_WSe2_ZnO"])
    for k, v in pairs.items():
        ax[0].loglog(dd6, dE_meV(sigma_gap_limit(dd6, v)), c=col[k], lw=1.8, label=f"{lab[k]} ({v:.2f} eV)")
        for dd in (0.3, 0.5, 1.0): w.writerow([k, v, dd, f"{float(dE_meV(sigma_gap_limit(dd, v))):.6g}", f"{(v/0.30)**2:.3f}"])
ax[0].text(0.55, 0.06, r"$\propto d^{-2}$", transform=ax[0].transAxes, fontsize=9, ha="center")
ax[0].set(xlabel="Interface thickness $d$ (nm)", ylabel=r"Upper-bound $|\Delta E_{ex}|$ (meV)", xlim=(0.29, 3), ylim=(0.01, 30))
ax[0].set_xticks([0.3, 0.5, 1, 2, 3]); ax[0].set_xticklabels(["0.3", "0.5", "1", "2", "3"]); ax[0].minorticks_off()
ax[0].legend(loc="lower left", fontsize=7); tag(ax[0], "(a)")
x = np.linspace(0.0, 0.85, 60); ax[1].plot(x, dE_meV(sigma_gap_limit(0.5, x)), "k", lw=1.2, label=r"$\propto(\Delta E_C)^2$")
off = {"MoS2/ZnO": (-7, 9, "right"), "WSe2/ZnO": (-8, 8, "right"), "WS2/ZnO": (9, -12, "left"),
       "WSe2/TiO2": (-9, -12, "right"), "WS2/TiO2": (-9, 8, "right")}
for k, v in pairs.items():
    y_ = float(dE_meV(sigma_gap_limit(0.5, v))); ax[1].plot(v, y_, "o", c=col[k], ms=6)
    ax[1].annotate(lab[k], (v, y_), xytext=off[k][:2], textcoords="offset points", fontsize=7.5, color=col[k], ha=off[k][2])
ax[1].set(xlabel=r"Conduction-band offset $\Delta E_C$ (eV)", ylabel=r"Upper-bound $|\Delta E_{ex}|$ (meV)", xlim=(0.0, 0.85), ylim=(0, 9))
ax[1].text(0.05, 0.80, "$d$ = 0.5 nm", transform=ax[1].transAxes, fontsize=8)
ax[1].legend(loc="upper left", fontsize=8); tag(ax[1], "(b)")
save(fig, "Figure6_generalisation")


# ---- parameter-sensitivity grid (Table 3) -----------------------------------
with open("data_sensitivity.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["dEC_eV", "eps_gap", "N_D_cm-3", "d_nm", "dE_selfconsistent_meV", "dE_upperbound_meV", "eta"])
    for dEC in (0.30, 0.50):
        for eg in (1, 2, 3):
            for nd in (1e17, 1e18, 1e19, 1e20):
                s_ = float(sigma_of_d(0.29, dEC, nd*1e6, eg))
                w.writerow([dEC, eg, f"{nd:.0e}", 0.29, f"{float(dE_meV(s_)):.4g}",
                            f"{float(dE_meV(sigma_gap_limit(0.29, dEC, eg))):.4g}", f"{float(eta_of_d(0.29, dEC, nd*1e6, eg)):.3f}"])

# ---- Report -----------------------------------------------------------------
if __name__ == "__main__":
    print(f"eps_eff (harmonic mean)            = {eps_eff:.2f}")
    print(f"lambda_TF 2D (eps=7,m*=0.45,g=2)   = {lambda_TF(7, m_star)*1e9:.3f} nm")
    for nd in (1e17, 1e18, 1e19): print(f"Debye length ZnO, N_D={nd:.0e} cm-3 = {debye_ZnO(nd*1e6)*1e9:.2f} nm")
    print(f"sigma_dep(0.30 V, 1e18 cm-3)       = {np.sqrt(2*eps0*eps_ZnO*e*N_D*0.30):.3e} C/m2")
    print(f"QCSE fit exponent (log-log)        = {slope:.3f}")
    print("\nTable 2: |dE_ex| (meV)   [self-consistent | upper bound eta=1]")
    for dEC in (0.30, 0.50):
        for dd in (0.29, 0.30, 0.50, 1.00):
            s = float(sigma_of_d(dd, dEC)); sb = float(sigma_gap_limit(dd, dEC))
            print(f"dEC={dEC:.2f} d={dd:.2f}: sigma={s:.3e} eta={float(eta_of_d(dd, dEC)):.3f} "
                  f"E_WSe2={E_perp(s)*1e-9:.4f} V/nm | dE={float(dE_meV(s)):.4f} | UB E={E_perp(sb)*1e-9:.3f} V/nm dE={float(dE_meV(sb)):.2f}")
    print("\nN_D sensitivity at dEC=0.30, d=0.30:")
    for nd in (1e17, 1e18, 1e19, 1e20):
        s = float(sigma_of_d(0.30, 0.30, nd*1e6)); print(f"  N_D={nd:.0e}: eta={float(eta_of_d(0.30,0.30,nd*1e6)):.3f} dE={float(dE_meV(s)):.4f} meV")
    print("\nSensitivity (Table 3): see data_sensitivity.csv")
    print("\nPair ratios (upper bound, equal d):")
    for k, v in pairs.items(): print(f"  {k}: dEC={v}  dE(d=0.5)={float(dE_meV(sigma_gap_limit(0.5, v))):.3f} meV  ratio to WSe2/ZnO={(v/0.30)**2:.2f}")
    print("\nDepletion width at d=0.3 nm: %.2f nm ; V_gap=%.4f V" % (W*1e9, Vg))
    for dc in (0.2, 0.4): print("dEC=%.1f: ratio to 0.30 = %.2f" % (dc, (dc/0.30)**2))
